#pragma once

#define HTTP_SERVER "143.198.225.87"
#define HTTP_PORT 80

#define TFTP_SERVER "143.198.225.87"
